#include "Display.h"
unsigned char code dis_tab[16]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71}; 
unsigned char data dis_data,bit_data;
signed char hour=10,minute=30,second=50;
signed char A_hour=10,A_minute=31,A_second=0;
signed char month=5,day=29;
signed short year=2025;
signed char week=1;
unsigned char intcnt=0;
unsigned char flash_flag = 0;
unsigned char flash_cnt = 0;
unsigned char days_in_month[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31}; // 1~12��
unsigned char max_day;

unsigned char get_week(unsigned short y, unsigned char m, unsigned char d)
{
    unsigned char w=0;
    if(m == 1 || m == 2)
    {
        m += 12;
        y--;
    }
    // 0=����, 1=��һ, ..., 6=����
    w = (d + 2*m + 3*(m+1)/5 + y + y/4 - y/100 + y/400) % 7+1;
    if(w == 7) 
     w=0; // 7=����
    return w;       // 1~6=��һ~����
}

void process(void)
{
    // �봦��
    if(second >= 60)
    {
        second = 0;
        minute++;
    }
    else if(second < 0) // �����-1
    {
        second = 59;
    }

    // ���Ӵ���
    if(minute >= 60)
    {
        minute = 0;
        hour++;
    }
    else if(minute < 0)
    {
        minute = 59;
    }

    // Сʱ����
    if(hour >= 24)
    {
        hour = 0;
        day++;
    }
    else if(hour < 0)
    {
        hour = 23;
    }
    // �ж�����2��
    max_day = days_in_month[month];
    if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
    max_day = 29;

    // ���ڴ���
    if(day > max_day)
    {
        day = 1;
        month++;
    }
    else if(day < 1)
    {
        if(month < 1)
        {
            month = 12;
        }
        // ���¼���max_day
        max_day = days_in_month[month];
        if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
        max_day = 29;
        day = max_day;
    }

    // �·ݴ���
    if(month > 12)
    {
        month = 1;
        year++;
    }
    else if(month < 1)
    {
        month = 12;
    }

    week = get_week(year, month, day);

}

void T0int(void) interrupt 1//��ʱ���жϣ�ÿ��һ���������һ
{
    TH0=19456/256;
    TL0=19456%256;
    if(set_mode == 0)
    {
        intcnt++;
        if(intcnt==20)
        {
            second++;
            intcnt=0;
        }
    }
}
void Timer1_ISR() interrupt 3
{
    TH1 = 0x3C;         // ��8λ��ֵ
    TL1 = 0xB0;         // ��8λ��ֵ

    flash_cnt++;
    if(flash_cnt >= 5) { // Լ500ms�л�һ��
        flash_cnt = 0;
        flash_flag = !flash_flag;
        flash_cnt=0;
    }
}
char *week_str[] = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
void Display(void)
{
        if(alarm_enable&&set_mode)
        {
            LCD_ShowString(2, 10, "ALM SET ");
            if(set_mode && set_item == 0 && flash_flag)
            LCD_ShowString(2, 1, "  ");         // ʱ��2λ��
            else
            LCD_ShowNum(2, 1, A_hour, 2);         // ʱ

            LCD_ShowChar(2, 3, ':');
            if(set_mode && set_item == 1 && flash_flag)
            LCD_ShowString(2, 4, "  ");         // �֣�2λ��
            else
            LCD_ShowNum(2, 4, A_minute, 2);       // ��
            LCD_ShowChar(2, 6, ':');
            if(set_mode && set_item == 2 && flash_flag)
            LCD_ShowString(2, 7, "  ");
            else 
            LCD_ShowNum(2, 7, A_second, 2);       // ��
        }
        else
        {
            if(set_mode && set_item == 0 && flash_flag&&SW)
            LCD_ShowString(1, 1, "    ");         // �꣨4λ��
            else
            LCD_ShowNum(1, 1, year, 4); 

            LCD_ShowChar(1, 5, '-');
            if(set_mode && set_item == 1 && flash_flag&&SW)
            LCD_ShowString(1, 6, "  ");         // �£�2λ��
            else
            LCD_ShowNum(1, 6, month, 2);        // �£�2λ��

            LCD_ShowChar(1, 8, '-');
            if(set_mode && set_item == 2 && flash_flag&&SW)
            LCD_ShowString(1, 9, "  ");
            else
            LCD_ShowNum(1, 9, day, 2);          // �գ�2λ��
            if(set_mode && set_item == 3 && flash_flag)
            LCD_ShowString(1, 12, "   ");
            else
            LCD_ShowString(1, 12, week_str[week]); // ���ڣ�3λ��
            if(set_mode && set_item == 0 && flash_flag)
            LCD_ShowString(2, 1, "  ");         // ʱ��2λ��
            else
            LCD_ShowNum(2, 1, hour, 2);         // ʱ
            LCD_ShowChar(2, 3, ':');
            if(set_mode && set_item == 1 && flash_flag)
            LCD_ShowString(2, 4, "  ");         // �֣�2λ��
            else
            LCD_ShowNum(2, 4, minute, 2);       // ��
            LCD_ShowChar(2, 6, ':');
            if(set_mode && set_item == 2 && flash_flag)
            LCD_ShowString(2, 7, "  ");
            else 
            LCD_ShowNum(2, 7, second, 2);       // ��
        }
            if(!alarm_enable)
            {
                LCD_ShowString(2, 10, "ALM OFF");
            }
            else
                if(!set_mode)
                LCD_ShowString(2, 10, "ALM ON ");
    }
