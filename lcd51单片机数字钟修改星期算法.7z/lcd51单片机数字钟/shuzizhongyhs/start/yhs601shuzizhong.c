#include <REG51.H>
#include <Display.h>
#include <Delay.h>
#include <TimInit.h>
#include <IOInit.h>
#include <Key.h>
#include <lcd1602.h>

void main()
{
    Tim_Init();
    LED1=1;
    LED2=0;
    LED3=1;
    LCD_Init();

    while(1)
    {
        if(!set_mode)
        {
            process();
        }
        Key0();
        Key1();
        Key2();
        Key3();
        alarm_process();
        Display();
    }
}
