#include <REG51.H>
#include <Display.h>
#include <Delay.h>
#include <TimInit.h>
#include <IOInit.h>
#include <Key.h>
extern unsigned char alarm_closed; 
void main()
{
    Tim_Init();
    LED1=1;
    LED2=0;
    LED3=1;
    while(1)
    {
        if(!set_mode)
        {
            process();
        }
        Key0();
        Key1();
        Key2();
        Key3();
        if(alarm_closed) 
        {
            alarm_flag = 0;
            LED4 = 1;
        }
        else
        if(A_hour==hour&&A_minute==minute)
        {
            alarm_flag=1;
            if(alarm_flag&& flash_flag)
            {
            LED4=0;
            }
            else
            LED4=1;
        }
        else
        {
            alarm_flag=0;
            LED4=1;
        }
    }
}
