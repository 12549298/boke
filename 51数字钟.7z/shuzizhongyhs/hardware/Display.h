#ifndef __DISPLAY_H
#define __DISPLAY_H
#include <REG51.H>
#include <Delay.h>
#include <IOInit.h>
#include <Key.h>
extern unsigned char set_mode; // 0:������1:����ģʽ
extern unsigned char set_item;
extern signed char A_hour;
extern signed char A_minute;
extern signed char A_second;
extern unsigned char flash_flag;
void WeekOnes(void);
void WeekTens(void);
void SecondOnes(void);
void SecondTens(void);
void MinuteOnes(void);
void MinuteTens(void);
void HourOnes(void);
void HourTens(void);
void DayTens(void);
void DayOnes(void);
void MonthTens(void);
void MonthOnes(void);
void YearThousands(void);
void YearHunders(void);
void YearTens(void);
void YearOnes(void);
void process(void);
void Display1(void);
void Display2(void);
void Display3(void);
unsigned char get_week(unsigned short y, unsigned char m, unsigned char d);
#endif