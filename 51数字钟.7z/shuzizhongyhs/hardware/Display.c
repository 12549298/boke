#include "Display.h"
unsigned char code dis_tab[16]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71}; 
unsigned char data dis_data,bit_data;
signed char hour=10,minute=30,second=50;
signed char A_hour=10,A_minute=31,A_second=0;
signed char month=5,day=29;
signed short year=2025;
signed char week=1;
unsigned char intcnt=0;
unsigned char flash_flag = 0;
unsigned char flash_cnt = 0;
signed char days_in_month[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31}; // 1~12��
signed char max_day;

unsigned char get_week(unsigned short y, unsigned char m, unsigned char d)
{
    unsigned char w=0;
    if(m == 1 || m == 2)
    {
        m += 12;
        y--;
    }
    // 0=����, 1=��һ, ..., 6=����
    w = (d + 2*m + 3*(m+1)/5 + y + y/4 - y/100 + y/400) % 7;
    if(w == 0) return 7; // 7=����
    else return w;       // 1~6=��һ~����
}
void WeekOnes(void)
{
    P2=0XFF;
    P0=dis_tab[week%10];//��λ
    P2=0XFE;
}

void WeekTens(void)
{
    P2=0XFF;
    P0=dis_tab[week/10];//ʮλ
    P2=0XFD;
}

void SecondOnes(void)//���λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[second%10]|0x80;//��λ
    P2=0XFB;
}

void A_SecondOnes(void)//�������λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[A_second%10]|0x80;//��λ
    P2=0XFB;
}

void SecondTens(void)//��ʮλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[second/10];//ʮλ
    P2=0XF7;
}

void A_SecondTens(void)//������ʮλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[A_second/10];//ʮλ
    P2=0XF7;
}

void MinuteOnes(void)//���Ӹ�λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[minute%10]|0x80;//��λ
    P2=0XEF;
}

void A_MinuteOnes(void)//���ӷ��Ӹ�λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[A_minute%10]|0x80;//��λ
    P2=0XEF;
}

void MinuteTens(void)//����ʮλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[minute/10];//ʮλ
    P2=0XDF;
}

void A_MinuteTens(void)//���ӷ���ʮλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[A_minute/10];//ʮλ
    P2=0XDF;
}

void HourOnes(void)//Сʱ��λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[hour%10]|0x80;//��λ
    P2=0XBF;
}

void A_HourOnes(void)//����Сʱ��λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[A_hour%10]|0x80;//��λ
    P2=0XBF;
}

void HourTens(void)//Сʱʮλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[hour/10];//ʮλ
    P2=0X7F;
}

void A_HourTens(void)//����Сʱʮλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[A_hour/10];//ʮλ
    P2=0X7F;
}

void YearOnes(void)//���λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[year%10]|0x80;//��λ
    P2=0XEF;
}

void YearTens(void)//��ʮλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[(year/10)%10];//ʮλ
    P2=0XDF;
}

void YearHunders(void)//���λ��ʾ
{
    P2=0XFF;
    P0=dis_tab[(year/100)%10];//��λ
    P2=0XBF;
}

void YearThousands(void)//��ǧλ��ʾ
{
    P2=0XFF;
    P0=dis_tab[year/1000];//ǧλ
    P2=0X7F;
}

void MonthOnes(void)
{
    P2=0XFF;
    P0=dis_tab[month%10]|0x80;//��λ
    P2=0XFB;
}

void MonthTens(void)
{
    P2=0XFF;
    P0=dis_tab[month/10];//ʮλ
    P2=0XF7;
}

void DayOnes(void)
{
    P2=0XFF;
    P0=dis_tab[day%10];//��λ
    P2=0XFE;
}

void DayTens(void)
{
    P2=0XFF;
    P0=dis_tab[day/10];//ʮλ
    P2=0XFD;
}


void process(void)
{
    // �봦��
    if(second >= 60)
    {
        second = 0;
        minute++;
    }
    else if(second < 0) // �����-1
    {
        second = 59;
    }

    // ���Ӵ���
    if(minute >= 60)
    {
        minute = 0;
        hour++;
    }
    else if(minute < 0)
    {
        minute = 59;
    }

    // Сʱ����
    if(hour >= 24)
    {
        hour = 0;
        day++;
        week++;
    }
    else if(hour < 0)
    {
        hour = 23;
    }
    // �ж�����2��
    max_day = days_in_month[month];
    if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
    max_day = 29;

    // ���ڴ���
    if(day > max_day)
    {
        day = 1;
        month++;
    }
    else if(day < 1)
    {
        if(month < 1)
        {
            month = 12;
        }
        // ���¼���max_day
        max_day = days_in_month[month];
        if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
        max_day = 29;
        day = max_day;
    }

    // �·ݴ���
    if(month > 12)
    {
        month = 1;
        year++;
    }
    else if(month < 1)
    {
        month = 12;
    }

    week = get_week(year, month, day)+1;

}

void T0int(void) interrupt 1//��ʱ���жϣ�ÿ��һ���������һ
{
    TH0=19456/256;
    TL0=19456%256;
    if(set_mode == 0)
    {
        intcnt++;
        if(intcnt==20)
        {
            second++;
            intcnt=0;
        }
    }
}

unsigned char show=0;

void Display1(void)//ʱ����������ʾ
{
        switch(show)
        {
            case 0:
                if(!(set_mode && set_item==2 && flash_flag))
                SecondOnes();
                break;
            case 1:
                if(!(set_mode && set_item==2 && flash_flag))
                SecondTens();
                break;
            case 2:
                if(!(set_mode && set_item==1 && flash_flag))
                MinuteOnes();
                break;
            case 3:
                if(!(set_mode && set_item==1 && flash_flag))
                MinuteTens();
                break;
            case 4:
                if(!(set_mode && set_item==0 && flash_flag))
                HourOnes();
                break;
            case 5:
                if(!(set_mode && set_item==0 && flash_flag))
                HourTens();
                break;
            case 6:
                if(!(set_mode && set_item==3 && flash_flag))
                WeekOnes();
                break;
            case 7:
                if(!(set_mode && set_item==3 && flash_flag))
                WeekTens();
                break;
        }
}

void Display2(void)//��������ʾ
{
        switch(show)
        {
            case 0:
                if(!(set_mode && set_item==0 && flash_flag))
                YearOnes();
                break;
            case 1:
                if(!(set_mode && set_item==0 && flash_flag))
                YearTens();
                break;
            case 2:
                if(!(set_mode && set_item==0 && flash_flag))
                YearHunders();
                break;
            case 3:
                if(!(set_mode && set_item==0 && flash_flag))
                YearThousands();
                break;
            case 4:
                if(!(set_mode && set_item==1 && flash_flag))
                MonthOnes();
                break;
            case 5:
                if(!(set_mode && set_item==1 && flash_flag))
                MonthTens();
                break;
            case 6:
                if(!(set_mode && set_item==2 && flash_flag))
                DayOnes();
                break;
            case 7:
                if(!(set_mode && set_item==2 && flash_flag))
                DayTens();
                break;
        }
}
void Display3(void)//����ʱ����ʾ
{
        switch(show)
        {
            case 0:
                if(!(set_mode && set_item==2 && flash_flag))
                A_SecondOnes();
                break;
            case 1:
                if(!(set_mode && set_item==2 && flash_flag))
                A_SecondTens();
                break;
            case 2:
                if(!(set_mode && set_item==1 && flash_flag))
                A_MinuteOnes();
                break;
            case 3:
                if(!(set_mode && set_item==1 && flash_flag))
                A_MinuteTens();
                break;
            case 4:
                if(!(set_mode && set_item==0 && flash_flag))
                A_HourOnes();
                break;
            case 5:
                if(!(set_mode && set_item==0 && flash_flag))
                A_HourTens();
                break;
        }
}
unsigned char SW=0;
void Timer1_ISR() interrupt 3
{
    TH1 = 0xEC;         // ��8λ��ֵ
    TL1 = 0x78;         // ��8λ��ֵ
    flash_cnt++;
    if(flash_cnt >= 50) // 0.5��
    {
        flash_cnt = 0;
        flash_flag = !flash_flag;
    }
    if(SW==0&&alarm_enable==0)
    {
        Display1();
    }
    else 
    if(SW==1&&alarm_enable==0)
    {
        Display2();
    }
    else
    {
        Display3();
    }
    show++;
    if(show==8)
    {
        show=0;
    }
}