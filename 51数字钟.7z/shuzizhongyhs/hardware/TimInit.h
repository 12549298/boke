#ifndef __TIMINIT_H
#define __TININIT_H
#include <REG51.H>

void Tim_Init(void);

#endif