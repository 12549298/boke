 #ifndef __KEY_H
#define __KEY_H
#include <REG51.H>
#include <IOInit.h>
#include <Display.H>
#include <Delay.h>
#include <oled.h>
extern unsigned char SW;
extern signed char hour,minute,second;
extern signed char month,day;
extern signed short year;
extern signed char week;
extern unsigned char days_in_month[13];
extern unsigned char max_day;
extern unsigned char alarm_enable;
extern unsigned char alarm_flag;
void Key0(void);
void Key1(void);
void Key2(void);
void Key3(void);
void alarm_process(void);
#endif