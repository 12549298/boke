#include <Key.h>
unsigned char SW=0;
unsigned char key_time = 0;
bit key_flag = 0; // ����������־
bit key_flag1 = 0; // ����������־
bit key_flag2 = 0; // ����������־
bit key_flag3 = 0; // ����������־
unsigned char alarm_enable = 0; // ���ӿ���
unsigned char alarm_flag = 0;   // �������־
unsigned char set_mode = 0; // 0:������1:����ģʽ
unsigned char set_item = 0; // 0:ʱ��1:�֣�2:��
void Key0(void)
{
    key_time = 0;
    if(K0==0&&key_flag==0)
    {
        mdelay(10);
        if(K0==0)
        {
            while(K0==0)
            {
                mdelay(10);
                key_time+=1;
                if(key_time>100)
                    break;
            }
            if(key_time<2)
            {
                //������������
            }
            else if(key_time<50)//�̰��¼�
            {
                if(set_mode == 0)//��ʾģʽ
                {
                    SW=!SW;//�л���ʾ
                    if(SW==0)//ָʾ��
                    {
                        LED1=1;
                        LED2=0;
                        LED3=1;
                    }
                    else
                    {
                        LED1=0;
                        LED2=1;
                        LED3=1;
                    }
                }
                else//����ģʽ�ٴζ̰�
                {
                    set_mode = 0; // �˳�����ģʽ
                    if(SW==0)//ָʾ��
                    {
                        LED1=1;
                        LED2=0;
                        LED3=1;
                    }
                    else
                    {
                        LED1=0;
                        LED2=1;
                        LED3=1;
                    }
                }
            }
            else//�����¼�
            {
                if(set_mode == 0)
                {
                        if(SW==0)
                        {
                            LED1=1;
                            LED2=0;
                            LED3=0;
                        }
                        else
                        {
                            LED1=0;
                            LED2=1;
                            LED3=0;
                        }
                    set_mode = 1; // �������ģʽ
                    set_item = 0;
                }
                else
                {
                    set_item++;
                    if(SW==0)
                    {
                        if(set_item > 3) //ʱ��������
                        {
                            set_item = 0;
                        }
                    }
                    else
                    {
                        if(set_item > 2) //������
                        {
                            set_item = 0;
                        }
                    }
                }
                
            }
            key_flag=1;
        }
    }
    if(K0==1)
        key_flag=0;
}

void Key1(void)
{
    if(K1==0 && key_flag1==0)
    {
        mdelay(10);
        if(K1==0)
        {
            if(set_mode) // ֻ�ڵ���ģʽ����Ч
            {
                if(SW==0&&alarm_enable==0)
                {
                    switch(set_item)
                    {
                        case 0: // ����Сʱ
                            hour = (hour+1)%24;
                            break;
                        case 1: // ���ڷ���
                            minute = (minute+1)%60;
                            break;
                        case 2: // ������
                            second = (second+1)%60;
                            break;
                        case 3:
                            week = (week+1)%7;
                            break;
                    }
                }
                else
                if (SW==1&&alarm_enable==0)
                {
                    switch(set_item)
                    {
                        case 0:
                        year = year+1;
                        break;
                        case 1:
                        month++;
                        max_day = days_in_month[month];
                        if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
                        max_day = 29;
                        if(day>max_day)
                        day=max_day;
                        if(month > 12) 
                        month = 1;
                        break;
                        case 2:
                        max_day = days_in_month[month];
                        if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
                        max_day = 29;
                        if(day<max_day)
                        day++;
                        else
                        day=1;
                        break;
                    }
                }
                else
                {
                    switch(set_item)
                    {
                        case 0: // ����Сʱ
                            A_hour = (A_hour+1)%24;
                            break;
                        case 1: // ���ڷ���
                            A_minute = (A_minute+1)%60;
                            break;
                        case 2: // ������
                            A_second = (A_second+1)%60;
                            break;
                    }
                }
                
            }
            key_flag1 = 1;
            while(K1==0); // �ȴ�����
        }
    }
    if(K1==1) key_flag1 = 0;
}
void Key2(void)
{
    if(K2==0 && key_flag2==0)
    {
        mdelay(10);
        if(K2==0)
        {
            if(set_mode) // ֻ�ڵ���ģʽ����Ч
            {
                if(SW==0&&alarm_enable==0)
                {   
                    switch(set_item)
                    {
                        case 0: // ����Сʱ
                            hour--;
                            if(hour<0)
                                hour=23;
                            break;
                        case 1: // ���ڷ���
                            minute--;
                            if(minute<0)
                                minute=59;
                            break;
                        case 2: // ������
                            second--;
                            if(second<0)
                                second=59;
                            break;
                        case 3:
                            week--;
                            if(week<0)
                                week=7;
                            break;
                    }
                }
                else
                if(SW==1&&alarm_enable==0)
                {
                    switch(set_item)
                    {
                        case 0:
                        year = year-1;
                        break;
                        case 1:
                        month--;
                        max_day = days_in_month[month];
                        if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
                        max_day = 29;
                        if(day>max_day)
                        day=max_day;
                        if(month < 1) 
                        month = 12;
                        break;
                        case 2:
                        max_day = days_in_month[month];
                        if(month == 2 && ((year%4==0 && year%100!=0) || (year%400==0)))
                        max_day = 29;
                        if(day>1)
                        day--;
                        else
                        day=max_day;
                        break;
                    }
                }
                else
                {
                    switch(set_item)
                    {
                        case 0: // ����Сʱ
                            A_hour--;
                            if(A_hour<0)
                                A_hour=24;
                            break;
                        case 1: // ���ڷ���
                            A_minute--;
                            if(A_minute<0)
                                A_minute=59;
                            break;
                        case 2: // ������
                            A_second--;
                            if(A_second<0)
                                A_second=59;
                            break;
                    }
                }
            }
            key_flag2 = 1;
            while(K2==0); // �ȴ�����
        }
    }
    if(K2==1) key_flag2 = 0;
}
unsigned char alarm_closed=0;
void Key3(void)
{
    unsigned char key3_time = 0;
    if(K3==0 && key_flag3==0)
    {
        mdelay(10);
        if(K3==0)
        {
            alarm_enable = !alarm_enable;
            key_flag3 = 1;
            while(K3==0); // �ȴ�����
        }
    }
    if(K3==1) 
        key_flag3 = 0;
}

void alarm_process(void)
{
        if(alarm_enable==0) 
        {
            alarm_flag = 0;
            LED4 = 1;
        }
        else
        if(A_hour==hour&&A_minute==minute)
        {
            alarm_flag=1;
            if(alarm_flag)
            {
            if(flash_flag)
            LED4=0;
            else
            LED4=1;
            }
            else
            LED4=1;
        }
        else
        {
            alarm_flag=0;
            LED4=1;
        }
}
