#ifndef __DELAY_H
#define __DELAY_H
#include <REG51.H>

void mdelay(unsigned int delay);
    
#endif

