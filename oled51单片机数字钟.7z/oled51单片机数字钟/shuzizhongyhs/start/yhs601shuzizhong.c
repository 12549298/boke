#include <REG51.H>
#include <Display.h>
#include <Delay.h>
#include <TimInit.h>
#include <IOInit.h>
#include <Key.h>
#include <oled.h>

void main()
{
    Tim_Init();
    LED1=1;
    LED2=0;
    LED3=1;
    OLED_Init();
    OLED_Display_On();
//    OLED_Clear();
    while(1)
    {
        if(!set_mode)
        {
            process();
        }
        Key0();
        Key1();
        Key2();
        Key3();
        alarm_process();
//        OLED_ShowString(0, 0, (u8*)"Hello", 16);
        Display();
    }
}
