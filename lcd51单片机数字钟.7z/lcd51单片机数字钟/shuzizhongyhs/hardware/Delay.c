#include "Delay.h"

void mdelay(unsigned int delay)
{
    unsigned int i;
    for(;delay>0;delay--)
    {
        for(i=0;i<54;i++);
    }
}