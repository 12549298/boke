#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Motor.h"  
#include "Motor_Init.h"  
#include <stdio.h>
#include <stdlib.h>
#include "usart.h"
#include "OLED1.h"
#include "movement.h"
#include "key.h"
#include "duoji.h"
#include "PWM.h"
#include "PWMG.h"
#include "cejv.h"//2100
//����79.5 Ҫ�ֳ���        //4�����ص�1cm
//#define  fangxia     565//mm
//#define  saomiao     438  //m  ??
//#define  zhuaqu      440//m 
//#define  zhuaqu_start 1145 //mm 
//#define  xuanzhuan     2300//mm
//#define  paowan   2100
//#define  saomiao_yld
//2300��ת2100��������
//ץ����  //��λ��׼ȷ
u16 receive_cnt;//����ɹ���������֡����
u8 confidence;
u16 distance1,distance2,noise,reftof; //distance1 Y��ʵ������ distance2 Xʵ������
u32 peak,intg;
u8 dis;
float x,real_cm1;
u8 huojia = 0,daowei0 = 0,daowei1 = 0,renwu_sta1,move_jilu = 0;




int main(void)     
{
    SystemInit();   // ��ʼ��ϵͳʱ��
	MOTOR_GPIO_Init();
	MOTOR_TIM_Init();
    Serial_Init ();
    OLED_Init();
    PWM_Init();
    PWMG_Init();
    uart2_4_init(230400);
    KEY_Init();
    suo();
    huojia = 0;
    Renwu = 0;
    Renwu1_State=0;
    renwu_sta1 = 0;
    real_cm1 = 0;
//     MOTOR_MoveUP((12)/StepDistance_Small,300,300,600); //����
//     suo();
//     while(motor_sta);
while(1)
{

    OLED_ShowFloatNum(2,10,distance2,4,4,OLED_6X8);
    OLED_ShowFloatNum(2,20,distance1,4,4,OLED_6X8);
    OLED_Update();

if(KEY_Scan()==1)
{        
        OLED_ShowString(2,50,"Start",OLED_6X8);
        OLED_Update();
        tuoluoyi_init();
        Delay_s(12);
        x = distance2 - zhuaqu_start;
        TrackingMovementX(x);
        y = distance1 - saomiao;
        TrackingMovementY(y);
//        y = distance1 - 2780;
//        TrackingMovementY(y);
//        x = distance2 - zhuaqu_start;
//        TrackingMovementX(x);
        TrackingMovementC(0);

      while(1)
       {
        tuoluoyi_init();
        OLED_ShowHexNum(2,30,serial_rxpacket1[0],4,OLED_6X8);
        OLED_ShowHexNum(2,40,serial_rxpacket2[0],4,OLED_6X8);
        OLED_ShowFloatNum(2,10,huojia,4,4,OLED_6X8);
        OLED_Update();
          //�ؼ�

//                  x = distance2 - xuanzhuan;
//                  TrackingMovementX(x); //�ܶ��٣� 640
//                  TrackingMovementC(90);
//                  Delay_ms(100);
//                  x = distance2 - 725;
//                  TrackingMovementX(x); //�ܶ��٣� 670
//                  TrackingMovementC(90);
         while(distance2 < paowan)
         {
         if(Renwu == 0)
           {
//��������1 ��־λ
            if(renwu_sta1 == 0)
            {
             Serial_SendByte(USART1,0x10);
             Delay_ms(100);
             Serial_SendByte(UART5,0x10);
             Delay_s(1);
             renwu_sta1 = 1;
            }
//�ȴ����
            Delay_s(2);
//û��⵽��Ʒ
            if(serial_rxpacket2[0]==0)
            {
              TrackingMovementX(-122);
            }
//              renwu1_4();
//��⵽��Ʒ
//              renwu1_2();
              renwu1_1();
              renwu1_3();
            }
           if(Renwu1_State >= 2)
           {
             x = distance2 - xuanzhuan;
             TrackingMovementX(x);
             TrackingMovementC(90);
             x = distance2 - 520; //���¼�¼
             TrackingMovementX(x);
             TrackingMovementC(90);
             y = distance1 - 3000;
             TrackingMovementY(y);
             while(1);
           }
         }
//�ܵ�����
          x = distance2 - xuanzhuan;
          TrackingMovementX(x); //�ܶ��٣� 640
          TrackingMovementC(90);
          Delay_ms(100);
          x = distance2 - 725;
          TrackingMovementX(x); //�ܶ��٣� 670
          TrackingMovementC(90);
          Delay_s(1);
//��ʼץ��һ������
          x = distance2 - zhuaqu_start;
          TrackingMovementX(x);
          y = distance1 - saomiao;
          TrackingMovementY(y);
          TrackingMovementC(0);
          daowei1 = 0;
          while(distance2 < paowan)
             {
                 if(Renwu == 0)
                   {

                    if(serial_rxpacket2[0] == 0)
                         {
                             TrackingMovementX(-122);
                         }
                         Delay_ms(500);
                         Delay_s(2);
                         //renwu1_4();
//                         renwu1_2();
                         renwu1_1();
                         renwu1_3();
                       //�ؼ�
                       if(Renwu1_State >= 2)
                       {                         
                         x = distance2 - 520;
                         TrackingMovementX(x);
                         y = distance1 - 3000;
                         TrackingMovementY(y);
                         while(1);
                       }
                    }
              }
          while(distance2 >= paowan)
          {
           x = distance2-520;
           TrackingMovementX(x);
           y = distance1 - 3000;
           TrackingMovementY(y);
           while(1);
          }
     }
}
}

}
