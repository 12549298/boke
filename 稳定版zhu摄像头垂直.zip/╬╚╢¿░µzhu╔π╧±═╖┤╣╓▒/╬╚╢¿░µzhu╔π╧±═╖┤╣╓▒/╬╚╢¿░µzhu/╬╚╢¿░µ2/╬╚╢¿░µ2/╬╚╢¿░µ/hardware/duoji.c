#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Motor.h"  
#include "Motor_Init.h"  
#include <stdio.h>
#include <stdlib.h>
#include "usart.h"
#include "OLED1.h"
#include "movement.h"
#include "duoji.h"
#include "PWM.h"
#include "PWMG.h"
#include "cejv.h"

extern uint32_t set_speed;         // ����ٶ����� ��λΪ0.1rad/sec
extern uint32_t step_accel;         // ���ٶ� ��λΪ0.1rad/sec^2
extern uint32_t step_decel;        // ���ٶ� ��λΪ0.1rad/sec^2
float StepDistance_Small = 0.000375; //С������� ��λcm/��
float distance_real1 = 0.0625; //����ת����ʵ��  ���ÿ���߶���cm�����������λֵ*��122�Ĳ�ֵ��ʵ�ʾ��롣
float distance_real2 = 0.0770;
float H_Limit_cmz = 0;
float y,real_cm,back_cm;
u8 H_State = 0,CI = 0;
u32 time = 0;
u8 Renwu1_State = 0, Renwu = 0;
extern u8 shanchu;
//����1�ĸ���Ʒ
unsigned int renwu1[4] = {0x10,0x11,0x12,0x13};
u8 renwu101 = 0,renwu102 = 0,renwu103 = 0,renwu104 = 0; //����1��־λ ��ִ��һ������һ������һ
u8 renwu201 = 0,renwu202 = 0,renwu203 = 0,renwu204 = 0; //����1��־λ ��ִ��һ������һ������һ
//�ڶ�������߶�56 -- 57��56   ��һ������߶�26  ����������߶� 74  (��������)
//ץȡ�߶��½� һ��


//����1
//11����  13���ֶ�
//10Ӫ������  12���� 

 
//����2
//��һ������    21RIO     ����22      �覰���ʺ��23 ��32   �Ӷ౦24
//����3��       31���    ����22      �覰32                �Ӷ౦24
    

//�ؽ�1��ͽǶȴ�ԼΪ33.4�� ������ٶȼǵ���    //0��צ���ſ���180��צ�ӱպ�  //
void fuwei(void)
{
 PWM_SetCompare1(90);
 PWM_SetCompare2(90);
 Delay_s(1);
 PWM_SetCompare3(135);
 Delay_s(1);
 PWM_SetCompare4(40);
}

void zhua(void)
{
 Delay_s(1);
 PWM_SetCompare1(45);
 PWM_SetCompare2(30);
 PWM_SetCompare3(170);
 Delay_s(1);
 PWM_SetCompare4(180);
 Delay_s(1);
}

void song (void)
{
 PWM_SetCompare1(100);
 PWM_SetCompare2(110);
 PWM_SetCompare3(200);
 Delay_s(1);
 PWM_SetCompare4(40);
 Delay_s(1);
}

void suo(void)
{
 PWM_SetCompare1(120);
 PWM_SetCompare2(0);
 PWM_SetCompare3(200);
 Delay_s(1);
 PWM_SetCompare4(40);
 Delay_s(1);
}
 
//�����½�
void floor_second_to_frist(void)
{
  MOTOR_MoveUP(28/StepDistance_Small,100,100,300);
  while(motor_sta);
}

void floor_second_to_third(void)
{
  MOTOR_MoveUP(-25/StepDistance_Small,100,100,300);
  while(motor_sta);
}


void floor_frist_to_thrid(void)
{
  MOTOR_MoveUP(-52/StepDistance_Small,100,100,300);
  while(motor_sta);
}


void floor_frist_to_second(void)
{
  MOTOR_MoveUP(-27/StepDistance_Small,100,100,300);
  while(motor_sta);
}

void floor_thrid_to_frist(void)
{
  MOTOR_MoveUP(52/StepDistance_Small,100,100,300);
  while(motor_sta);
}


void floor_thrid_to_second(void)
{
  MOTOR_MoveUP(25/StepDistance_Small,100,100,300);
  while(motor_sta);
}



//˿�˺�����λ  
//1.�Ѿ����˶��پ��� �������������ж��Ƿ�ӽ���λ������ӽ���λ������Ҫ�ƶ��ľ���ܴ�Ӧ����ô����
//5.��CM����ʱ���Ѿ����뵽ʵ���ƶ������У��������ٷ�Χ����Ҫ��CM���㲻�����ƶ�  >?
//2.���ж����Ѿ�������֮�󣨶���CMֵ��ʵ���ƶ��Ĵ�����
//3.��û��ɨ�赽��Ʒ�������׳���
//4.��������ɨ�赽��Ʒ��Ѱ�����ĵ�Ķ������뵽��λ�����У������ڽӽ���λ����ʱ�Ĵ�����
//6.�������ڲ��������ݵĻ�ȡ��ֱ���ں����ڼӽ�ȥ������float CM


void Limit_H(float CM) 
{   
//�Լ�H_Limit_cmz = H_Limit_cmz + CM;
//δ��⵽��Ʒ
    H_Limit_cmz = H_Limit_cmz + CM;
//    OLED_ShowFloatNum(2,10,1,3,4,OLED_6X8);
//    OLED_ShowFloatNum(2,10,H_Limit_cmz,3,4,OLED_6X8);
//    OLED_Update();
//    OLED_ShowFloatNum(2,10,distance2,4,4,OLED_6X8);
//    OLED_ShowHexNum(2,20,serial_rxpacket1[1],4,OLED_6X8);
//    OLED_ShowHexNum(2,30,serial_rxpacket1[0],4,OLED_6X8);
//    OLED_ShowHexNum(2,40,serial_rxpacket2[0],4,OLED_6X8);
//    OLED_Update();
    if(H_State == 0)
        {
              if( H_Limit_cmz >= 19  ) //˿����λ��Ҫ����ȷ���ݣ��ǵò���
                  {
                    MOTOR_MoveH(-H_Limit_cmz/StepDistance_Small,300,300,300);
                    while(motor_sta);
                      
                    OLED_ShowFloatNum(2,10,2,3,4,OLED_6X8);
                    OLED_ShowFloatNum(2,10,H_Limit_cmz,3,4,OLED_6X8);
                    OLED_Update();
                      
                      
                    Delay_s(1);
                    H_Limit_cmz = 0;  //����λ����
                    H_State = 1; //��־λ��1
                    Delay_s(1);
                  }
              else if( H_Limit_cmz <= -19)
                  {
                    MOTOR_MoveH(-H_Limit_cmz/StepDistance_Small,300,300,300);
                    while(motor_sta);
                      
                    OLED_ShowFloatNum(2,10,2,3,4,OLED_6X8);
                    OLED_ShowFloatNum(2,10,H_Limit_cmz,3,4,OLED_6X8);
                    OLED_Update();
                      
                      
                    Delay_s(1);
                    H_Limit_cmz = 0;//����λ����
                    H_State = 1;//��־λ��1
                    Delay_s(1);
                  }
        }
        
        
//     if (H_State == 1)
//        {
//                    OLED_ShowFloatNum(2,10,2,3,4,OLED_6X8);
                    OLED_ShowFloatNum(2,40,H_Limit_cmz,3,4,OLED_6X8);
                    OLED_Update();
                    Delay_s(5);
//           
//          TrackingMovementX(-122);   //�ݶ��������ƶ���Ҫ������һ���ƶ�������������ͷ
//          H_State = 0;
//        }
}



//����1
void renwu1_1 (void) //��������
{
        if(serial_rxpacket2[0] == renwu1[0])//��⵽��Ʒ������������
        {
         MOTOR_MoveUP(-9/StepDistance_Small,300,300,300);     //����//�ǵò����
         while(motor_sta);
         Delay_s(2);
         if(serial_rxpacket1[0] == renwu1[0])
         {
         while(1)
         {
          real_cm = (serial_rxpacket1[1] - 103) * distance_real2 ;
          back_cm = back_cm + real_cm;
          Limit_H(-real_cm);
          MOTOR_MoveH(-real_cm/StepDistance_Small,100,100,300);
          while(motor_sta);
          Delay_ms(500);
          if(serial_rxpacket1[1]>=98 && serial_rxpacket1[1]<=110)
           { 
               Serial_SendByte(UART5,0xA0);
               Serial_SendByte(USART1,0xA0);
               MOTOR_MoveUP(18/StepDistance_Small,300,300,600); //�½�//����Ҫ��
               while(motor_sta);
               Delay_ms(100);
               y = distance1 - fangxia;
               TrackingMovementY(y);
               PWM_SetCompare1(45);
               PWM_SetCompare2(30);
               PWM_SetCompare3(170);
               Delay_ms(500);
               y = distance1 - zhuaqu ;
               TrackingMovementY(y);
               Delay_ms(500);
               PWM_SetCompare4(180);
              //ȡ��
               Delay_ms(500);
               PWM_SetCompare3(180);//΢̧��
               Delay_ms(500);
               y = distance1 - fangxia;      
               TrackingMovementY(y);    
               PWM_SetCompare1(100);
               PWM_SetCompare2(110);
               PWM_SetCompare3(200);
               Delay_ms(500);
               PWM_SetCompare4(40);
               Delay_ms(500);
//               y = distance1 - fangxia;      
//               TrackingMovementY(y);
               MOTOR_MoveUP(-9/StepDistance_Small,300,300,600); //����//���������� = ����ͷ�����ľ���
               suo();
               while(motor_sta);
               Delay_ms(500);
               y = distance1 - saomiao;      
               TrackingMovementY(y);
               Delay_ms(500);
               MOTOR_MoveH(back_cm/StepDistance_Small,100,100,300);
               while(motor_sta);
               back_cm = 0;
               real_cm = 0;
               serial_rxpacket1[1] = 0;
               serial_rxpacket1[0] = 0;
               serial_rxpacket2[0] = 0;
               Renwu1_State = Renwu1_State+1;
               
               break;
            }
         }
         }
         else
         {
          MOTOR_MoveUP(10/StepDistance_Small,300,300,300);     //����//�ǵò����
          while(motor_sta);
          TrackingMovementX(-122);
         }
	   }

}



void renwu1_2 (void)  //���ֶ�   //�½�����  צ�ӵ��� ���ֶ�С
{
        if(serial_rxpacket2[0] == renwu1[3])
        {
         MOTOR_MoveUP(-9/StepDistance_Small,300,300,300);     //����//�ǵò����
         while(motor_sta);
         Delay_s(2);
         if(serial_rxpacket1[0] == renwu1[3])
         {
         while(1)
         {
          real_cm = (serial_rxpacket1[1] - 103) * distance_real2 ;
          back_cm = back_cm + real_cm;
          Limit_H(-real_cm);
          MOTOR_MoveH(-real_cm/StepDistance_Small,100,100,300);
          while(motor_sta);
          Delay_ms(500);
          if(serial_rxpacket1[1]>=100 && serial_rxpacket1[1]<=110)
           { 
               Serial_SendByte(UART5,0xA3);
               Serial_SendByte(USART1,0xA3);
               MOTOR_MoveUP(21/StepDistance_Small,300,300,600); //�½�
               while(motor_sta);
               y = distance1 - fangxia;
               TrackingMovementY(y);
               Delay_ms(100);
               PWM_SetCompare1(45);
               PWM_SetCompare2(30);
               PWM_SetCompare3(170);
               Delay_ms(100);
               y = distance1 - zhuaqu;
               TrackingMovementY(y);
               Delay_ms(500);
               PWM_SetCompare4(180);
              //ȡ��
               Delay_ms(500);
               PWM_SetCompare3(180);//΢̧��
               Delay_ms(100);
               y = distance1 - fangxia;      
               TrackingMovementY(y);               
               PWM_SetCompare1(100);
               PWM_SetCompare2(110);
               PWM_SetCompare3(200);
               Delay_ms(500);
               PWM_SetCompare4(40);
               Delay_ms(100);
//               y = distance1 - fangxia;      
//               TrackingMovementY(y);
               MOTOR_MoveUP(-14/StepDistance_Small,300,300,600); //����
               suo();
               while(motor_sta);
               y = distance1 - saomiao;      
               TrackingMovementY(y);
               Delay_ms(100);
               MOTOR_MoveH(back_cm/StepDistance_Small,100,100,300);
               while(motor_sta);
               real_cm = 0 ;
               back_cm = 0;
               serial_rxpacket1[1] = 0;
               serial_rxpacket1[0] = 0;
               serial_rxpacket2[0] = 0;
               Renwu1_State = Renwu1_State+1;

               break;
            }
         }
         }
     }

}




void renwu1_3 (void)//���¿���
{
        if(serial_rxpacket2[0] == renwu1[2] )
        {
         MOTOR_MoveUP(-10/StepDistance_Small,300,300,300);     //����//�ǵò����
         while(motor_sta);
         Delay_s(2);
         if(serial_rxpacket1[0] == renwu1[2])
         {
         while(1)
         {
          real_cm = (serial_rxpacket1[1] - 103) * distance_real2 ;
          back_cm = back_cm + real_cm;
          MOTOR_MoveH(-real_cm/StepDistance_Small,100,100,300);
          while(motor_sta);
          Delay_ms(500);
          if(serial_rxpacket1[1]>=98 && serial_rxpacket1[1]<=110)
           { 
               Serial_SendByte(UART5,0xA2);
               Serial_SendByte(USART1,0xA2);
               MOTOR_MoveUP(20/StepDistance_Small,300,300,600); //�½�
               while(motor_sta);
               Delay_ms(100);
               y = distance1 - fangxia;
               TrackingMovementY(y);
               PWM_SetCompare1(45);
               PWM_SetCompare2(30);
               PWM_SetCompare3(170);
               Delay_ms(500);
               y = distance1 - zhuaqu ;
               TrackingMovementY(y);
               Delay_ms(500);
               PWM_SetCompare4(180);
              //ȡ��
               Delay_ms(500);
               PWM_SetCompare3(180);//΢̧��
               Delay_ms(500);
               y = distance1 - fangxia;      
               TrackingMovementY(y);
               PWM_SetCompare1(100);
               PWM_SetCompare2(110);
               PWM_SetCompare3(200);
               Delay_ms(500);
               PWM_SetCompare4(40);
               Delay_ms(500);
//               y = distance1 - fangxia;      
//               TrackingMovementY(y);
               MOTOR_MoveUP((-13)/StepDistance_Small,300,300,600); //����
               suo();
               while(motor_sta);
               Delay_ms(500);
               y = distance1 - saomiao;      
               TrackingMovementY(y);
               MOTOR_MoveH(back_cm/StepDistance_Small,100,100,300);
               while(motor_sta);
               real_cm = 0 ;
               back_cm = 0;
               serial_rxpacket1[1] = 0;
               serial_rxpacket1[0] = 0;
               serial_rxpacket2[0] = 0;
               Renwu1_State = Renwu1_State+1;
               break;
            }
         }
         }
         else
         {
          MOTOR_MoveUP(10/StepDistance_Small,300,300,300);     //����//�ǵò����
          while(motor_sta);
          TrackingMovementX(-122);
         }
	   }
}




void renwu1_4 (void)//����
{
         if(serial_rxpacket1[0] == renwu1[1])
         {
         while(1)
         {
          real_cm = (serial_rxpacket1[1] - 103) * distance_real2 ;
          back_cm = back_cm + real_cm;
          MOTOR_MoveH(-real_cm/StepDistance_Small,100,100,300);
          while(motor_sta);
          if(serial_rxpacket1[1]>=100 && serial_rxpacket1[1]<=110)
           { 
               Serial_SendByte(UART5,0xA1);
               Serial_SendByte(USART1,0xA1);
               MOTOR_MoveUP(10/StepDistance_Small,300,300,600); //�½�
               while(motor_sta);
               Delay_ms(100);
               y = distance1 - fangxia;
               TrackingMovementY(y);
               PWM_SetCompare1(45);
               PWM_SetCompare2(30);
               PWM_SetCompare3(170);
               Delay_ms(500);
               y = distance1 - zhuaqu ;
               TrackingMovementY(y);
               Delay_ms(500);
               PWM_SetCompare4(180);
              //ȡ��
               Delay_ms(500);
               PWM_SetCompare3(180);//΢̧��
               Delay_ms(500);
               y = distance1 - fangxia;      
               TrackingMovementY(y);
               PWM_SetCompare1(100);
               PWM_SetCompare2(110);
               PWM_SetCompare3(200);
               Delay_ms(500);
               PWM_SetCompare4(40);
               Delay_ms(500);
//               y = distance1 - fangxia;      
//               TrackingMovementY(y);
               MOTOR_MoveUP((-10*1.01)/StepDistance_Small,300,300,600); //����
               suo();
               while(motor_sta);
               Delay_ms(500);
               y = distance1 - saomiao;      
               TrackingMovementY(y);
               MOTOR_MoveH(back_cm/StepDistance_Small,100,100,300);
               while(motor_sta);
               real_cm = 0 ;
               back_cm = 0;
               serial_rxpacket1[1] = 0;
               serial_rxpacket1[0] = 0;
               serial_rxpacket2[0] = 0;
               Renwu1_State = Renwu1_State+1;
               break;
            }
         }
         }
}



//����2 1.˿����Ҫ��ԭ��ԭλ 2.�߶���Ҫ����һ�� 3.����������˿��ԭλ

void renwu2_1(void)  //����
{
  if(serial_rxpacket1[0] == 0x22)
  {
         Serial_SendByte(USART1,0xB2);
         TrackingMovementX(-120);//�ƶ�����ͷ����
         while(1)
         {
          serial_rxpacket1[0] = 0;
          Delay_ms(100);
          real_cm = (serial_rxpacket1[1] - 155)*0.0625;
          MOTOR_MoveH(-real_cm/StepDistance_Small,100,100,100);  //ʵ�ʲ��ԣ���ÿȦ���ٸ���  1cm 4��  //0.45
          while(motor_sta);
          Delay_s(1);
          if(serial_rxpacket1[1]>=150 && serial_rxpacket1[1]<=165)
           { 
               MOTOR_MoveUP(SPR*2.6,300,300,500); //�½�
               while(motor_sta);
               y = distance1 - fangxia;
               TrackingMovementY(y);
               Delay_s(1);
               PWM_SetCompare1(45);
               PWM_SetCompare2(30);
               PWM_SetCompare3(170);
               Delay_s(1);
               y = distance1 - zhuaqu ;
               TrackingMovementY(y);
               Delay_s(1);
               PWM_SetCompare4(180);
               Delay_s(1);
              //ȡ�� ///צ��λ�õ�����suo��״̬
               Delay_s(1);
               PWM_SetCompare3(180);//΢̧��
               y = distance1 - fangxia;      
               TrackingMovementY(y);
               suo();
               
               //������������
               floor_frist_to_thrid();
               y = distance1 - saomiao;      
               TrackingMovementY(y);
               //��������
               
//              Delay_ms(100);
//              Limit_H(0.5);
//              MOTOR_MoveH(0.5/StepDistance_Small,300,300,300);
//              while(motor_sta);
               //����
               if(serial_rxpacket1[0] == 0x22)
               {
                 Delay_s(1);
                 PWM_SetCompare1(45);
                 PWM_SetCompare2(30);
                 PWM_SetCompare3(170);
                 Delay_s(1);
                 PWM_SetCompare4(40);
                 Delay_s(1);
                 suo();
                 Delay_s(1);
               //����
                 y = distance1 - fangxia;      
                 TrackingMovementY(y);
               //�½�����һ��
                 floor_thrid_to_frist();
                 MOTOR_MoveUP(SPR*2.6,300,300,600); 
                 while(motor_sta);
                 y = distance1 - saomiao;      
                 TrackingMovementY(y);
//                 Renwu2_State++;
                 serial_rxpacket1[1] = 0;
                 serial_rxpacket1[0] = 0;
                 break;
               }
            }
         }
   }
}




