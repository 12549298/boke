#ifndef __PWM_H
#define __PWM_H
#include "stm32f10x.h"                  // Device header


void PWM_Init(void);
void PWM_SetCompare1(float Compare);
void PWM_SetCompare2(float Compare);
void PWM_SetCompare4(float Compare);
void Servo_SetAngle_TIM2_1(float Angle2_1);
void Servo_SetAngle_TIM2_2(float Angle2_2);
void Servo_SetAngle_TIM2_3(float Angle2_3);    
void Servo_SetAngle_TIM2_4(float Angle2_4);



#endif

