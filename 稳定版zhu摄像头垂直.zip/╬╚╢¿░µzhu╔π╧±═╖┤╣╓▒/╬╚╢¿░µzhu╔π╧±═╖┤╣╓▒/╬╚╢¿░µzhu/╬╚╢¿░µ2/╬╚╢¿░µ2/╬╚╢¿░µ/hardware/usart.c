#include "usart.h"
uint8_t serial_rxdata;
uint8_t serial_rxflag;
uint8_t serial_txpacket[10];
uint8_t serial_rxpacket1[3];//����ͷ����
uint8_t serial_rxpacket2[3];//����ͷ2����
static uint8_t RxBuffer[11];/*������������*/
static volatile uint8_t RxState = 0;/*����״̬��־λ*/
static uint8_t RxIndex = 0;/*������������*/
float Yaw;/*�Ƕ���Ϣ�����ֻ��Ҫ�������Ը�Ϊ��������*/
float valuex=0;//����
float value2=0;//����
uint8_t ZZHOUZHILING[]={0XFF,0XAA,0X52};//Z������
uint8_t JIASUDUJIAOZHUN[]={0XFF,0XAA,0X67};//���ٶȼ�У׼
u8 shanchu = 0;
void  Serial_Init ()
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);
    
  //��ʼ��ʱ��
  GPIO_InitTypeDef GPIO_InitStrcuture;
  GPIO_InitStrcuture.GPIO_Mode= GPIO_Mode_AF_PP;
  GPIO_InitStrcuture.GPIO_Pin= GPIO_Pin_9|GPIO_Pin_2;
  GPIO_InitStrcuture.GPIO_Speed=GPIO_Speed_50MHz ;
  GPIO_Init(GPIOA,&GPIO_InitStrcuture);
  GPIO_InitStrcuture.GPIO_Pin= GPIO_Pin_10;
  GPIO_Init(GPIOB,&GPIO_InitStrcuture);
  GPIO_InitStrcuture.GPIO_Pin= GPIO_Pin_10|GPIO_Pin_12;
  GPIO_Init(GPIOC,&GPIO_InitStrcuture);
  GPIO_InitStrcuture.GPIO_Mode= GPIO_Mode_IPU;
  GPIO_InitStrcuture.GPIO_Pin= GPIO_Pin_10|GPIO_Pin_3;
  GPIO_Init(GPIOA,&GPIO_InitStrcuture);
  GPIO_InitStrcuture.GPIO_Pin= GPIO_Pin_11;
  GPIO_Init(GPIOB,&GPIO_InitStrcuture);
  GPIO_InitStrcuture.GPIO_Pin= GPIO_Pin_11;
  GPIO_Init(GPIOC,&GPIO_InitStrcuture);
  GPIO_InitStrcuture.GPIO_Pin= GPIO_Pin_2;
  GPIO_Init(GPIOD,&GPIO_InitStrcuture);
  //��ʼ��USART
   USART_InitTypeDef USART_inititructure;
   USART_inititructure.USART_BaudRate = 9600;
   USART_inititructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
   USART_inititructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
   USART_inititructure.USART_Parity=USART_Parity_No;
   USART_inititructure.USART_StopBits=USART_StopBits_1;
   USART_inititructure.USART_WordLength=USART_WordLength_8b;
   USART_Init(USART3,&USART_inititructure);    
   USART_inititructure.USART_BaudRate = 115200;
   USART_Init(USART1,&USART_inititructure);
   USART_Init(UART5,&USART_inititructure);
   USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
   USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
   USART_ITConfig(UART5,USART_IT_RXNE,ENABLE);
   
   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
   NVIC_InitTypeDef nvic_initstructure;
   nvic_initstructure.NVIC_IRQChannel=USART1_IRQn;
   nvic_initstructure.NVIC_IRQChannelCmd=ENABLE;
   nvic_initstructure.NVIC_IRQChannelPreemptionPriority=0;
   nvic_initstructure.NVIC_IRQChannelSubPriority=2;
   NVIC_Init(&nvic_initstructure);
   nvic_initstructure.NVIC_IRQChannelSubPriority=0;
   nvic_initstructure.NVIC_IRQChannel=UART5_IRQn;
   NVIC_Init(&nvic_initstructure);
   
   nvic_initstructure.NVIC_IRQChannelPreemptionPriority=0;
   nvic_initstructure.NVIC_IRQChannelSubPriority=3;
   nvic_initstructure.NVIC_IRQChannel=USART3_IRQn;
   NVIC_Init(&nvic_initstructure);
   USART_Cmd(USART1,ENABLE);
   USART_Cmd(USART3,ENABLE);
   USART_Cmd(UART5,ENABLE);
}



void Serial_SendByte(USART_TypeDef* USARTx,int16_t byte)
{
   USART_SendData(USARTx,byte);
   while(USART_GetFlagStatus(USARTx,USART_FLAG_TXE) == RESET);
}

void serial_sendarray(USART_TypeDef* USARTx,uint8_t *array,uint16_t length)
{
    uint16_t i;
    for(i=0;i<length;i++)
    {
        Serial_SendByte(USARTx,array[i]);
    }
}

void serial_sendstring(USART_TypeDef* USARTx,char*string)
{
    uint8_t i;
    for(i=0;string[i]!='\0';i++)
    {
        Serial_SendByte(USARTx,string[i]);
    }
}

uint32_t serial_pow(uint32_t x,uint32_t y)
{
    uint32_t result=1;
    while(y--)
    {
        result*=x;
    }
    return result;
}

void serial_sendnumber(USART_TypeDef* USARTx,uint32_t number,uint8_t length)
{
    uint8_t i;
    for(i=0;i<length;i++)
    {
        Serial_SendByte(USARTx,number/serial_pow(10,length-i-1)%10+'0');
    }
}

int fputc(int ch,FILE*f)
{
    Serial_SendByte(USART1,ch);
    Serial_SendByte(USART2,ch);
    return ch;
}

uint8_t serial_getrxflag(void)
{
    if(serial_rxflag==1)
    {
        serial_rxflag=0;
        return 1;
    }
    return 0;
}

void serial_sendpacket(USART_TypeDef* USARTx)
{
    serial_sendarray(USARTx,serial_txpacket,10);
}

void tuoluoyi_init(void)
{
    serial_sendarray(USART3,JIASUDUJIAOZHUN,3);
    Delay_ms(500);
    serial_sendarray(USART3,ZZHOUZHILING,3);
    Delay_ms(500);
}

void jy61p_ReceiveData(uint8_t RxData)
 {
	uint8_t i,sum=0;
	
	if (RxState == 0)	//�ȴ���ͷ
	{
        
		if (RxData == 0x55)	//�յ���ͷ
		{
			RxBuffer[RxIndex] = RxData;
			RxState = 1;
			RxIndex = 1; //������һ״̬
		}
	}
    
	else if (RxState == 1)
	{
		if (RxData == 0x53)	/*�ж��������ݣ��޸�������Ըı�Ҫ�����������ݣ�0x53Ϊ�Ƕ����*/
		{
			RxBuffer[RxIndex] = RxData;
			RxState = 2;
			RxIndex = 2; //������һ״̬
		}
	}
    
	else if (RxState == 2)	//��������
	{
		RxBuffer[RxIndex++] = RxData;
		if(RxIndex == 11)	//�������
		{
			for(i=0;i<10;i++)
			{
				sum = sum + RxBuffer[i]; //����У���
			}
			if(sum == RxBuffer[10])		//У��ɹ�
			{
				Yaw = ((uint16_t) ((uint16_t) RxBuffer[7] << 8 | (uint16_t) RxBuffer[6])) / 32768.0f * 180.0f;//360��汾
//                if(Yaw>180&&Yaw<360)//180��汾
//                    Yaw=Yaw-360;
			}
			RxState = 0;
			RxIndex = 0; //��ȡ��ɣ��ص����״̬���ȴ���ͷ
		}
	}
}

static uint8_t rxstate1=0;
static uint8_t prxpack1=0;

void USART1_IRQHandler(void)    //����ͷ����
{   

    if(USART_GetITStatus(USART1,USART_IT_RXNE)==SET)
    {
        uint8_t rxdata=USART_ReceiveData(USART1);
        if(rxstate1==0)
        {
            if (rxdata==0xFF)
            {
                rxstate1=1;
                prxpack1=0;
            }
        }
        else if(rxstate1==1)
        {
            serial_rxpacket1[prxpack1]=rxdata;
            prxpack1++;
            if(prxpack1>=3)
            {
                rxstate1=2;
            }
        }else if(rxstate1==2)
        {
            if(rxdata==0xFE)
            {
                rxstate1=0;
                serial_rxflag=1;
            }
        } 
    }

}

static uint8_t rxstate2=0;
static uint8_t prxpack2=0;
void UART5_IRQHandler(void)    //����ͷ����
{   
    if(USART_GetITStatus(UART5,USART_IT_RXNE)==SET)
    {
        uint8_t rxdata=USART_ReceiveData(UART5);
        if(rxstate2==0)
        {
            if (rxdata==0xFF)
            {
                rxstate2=1;
                prxpack2=0;
            }
        }
        else if(rxstate2==1)
        {
            serial_rxpacket2[prxpack2]=rxdata;
            prxpack2++;
            if(prxpack2>=3)
            {
                rxstate2=2;
            }
        }else if(rxstate2==2)
        {
            if(rxdata==0xFE)
            {
                rxstate2=0;
                serial_rxflag=1;
            }
        }
    }
}


void USART3_IRQHandler(void)    //�����ǽ���
{

    	uint8_t RxData;
	if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
	{
		RxData = USART_ReceiveData(USART3);	/*��ȡ���յ�������*/

		jy61p_ReceiveData(RxData);	/*�������ݰ���������*/
        
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);

	}
}
