#ifndef __PWMG_H
#define __PWMG_H
#include "stm32f10x.h"                  // Device header


void PWMG_Init(void);
void PWM_SetCompare3(float Compare);



#endif
