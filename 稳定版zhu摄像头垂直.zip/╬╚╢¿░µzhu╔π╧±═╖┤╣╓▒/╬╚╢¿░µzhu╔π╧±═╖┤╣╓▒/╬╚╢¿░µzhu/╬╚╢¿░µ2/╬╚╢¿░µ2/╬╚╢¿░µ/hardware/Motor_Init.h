#ifndef __Motor_Init_H
#define __Motor_Init_H
#include "stm32f10x.h"                  // Device header
#include "math.h"
#include "Motor.h"  



//����Ƚ�ģʽ��������Ϊ0xFFFF
#define TIM_PERIOD                   0xFFFF



void MOTOR_GPIO_Init(void);
void MOTOR_TIM_Init(void);


#endif

