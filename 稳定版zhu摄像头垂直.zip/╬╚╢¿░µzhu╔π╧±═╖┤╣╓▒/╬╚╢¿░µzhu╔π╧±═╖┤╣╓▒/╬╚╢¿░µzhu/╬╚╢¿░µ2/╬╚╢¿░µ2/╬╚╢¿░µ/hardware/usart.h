#ifndef __USART_H
#define __USART_H
#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <Delay.h>
#include <OLED1.h>
extern uint8_t serial_rxdata;
extern uint8_t serial_rxflag;
extern uint8_t serial_txpacket[10];
extern uint8_t serial_rxpacket1[3];
extern uint8_t serial_rxpacket2[3];
extern uint8_t ZZHOUZHILING[];//Z������
extern uint8_t JIASUDUJIAOZHUN[];//���ٶȼ�У׼
extern float Yaw;
extern float valuex;

//extern float valuey;
void  Serial_Init (void);
void Serial_SendByte(USART_TypeDef* USARTx,int16_t byte);
void serial_sendarray(USART_TypeDef* USARTx,uint8_t *array,uint16_t length);
void serial_sendstring(USART_TypeDef* USARTx,char*string);
void serial_sendnumber(USART_TypeDef* USARTx,uint32_t number,uint8_t length);
uint8_t serial_getrxflag(void);
void serial_sendpacket(USART_TypeDef* USARTx);
void jy61p_ReceiveData(uint8_t RxData);
void tuoluoyi_init(void);
#endif
